#!/bin/bash
# Bundle Python dependencies for Lambda

pip install -r requirements.txt -t .
